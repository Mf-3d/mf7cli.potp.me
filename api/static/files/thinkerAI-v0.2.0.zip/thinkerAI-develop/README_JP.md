<table>
<tbody>
  <tr>
    <td><a href="https://github.com/mf-3d/thinkerAI#readme">English</a></td>
    <td><a href="https://github.com/mf-3d/thinkerAI/blob/main/README_JP.md">日本語</a></td>
  </tr>
  </tbody>
</table>

<img src="./img/logo/logo_and_text.png" width="500">

thinkerAIはGPT-2を使用した、拡張可能な雑談AIのプラットフォームです。

# thinkerAIとはなんですか？

thinkerAIは、GPT-2の雑談AIの作成を簡単にすることができるプラットフォームです。
このプラットフォームの目標は、AIをもっと利用しやすくすることです。

*将来的には、GUIでも操作できるようにする予定です。*

[![License: MIT](https://img.shields.io/badge/license-MIT-blue.svg)](LICENSE)