<table>
<tbody>
  <tr>
    <td><a href="https://github.com/mf-3d/thinkerAI/blob/main/docs/train.md">English</a></td>
    <td><a href="https://github.com/mf-3d/thinkerAI/blob/main/docs/train_JP.md">日本語</a></td>
  </tr>
  </tbody>
</table>

<!-- **thinkerAIの初回起動用の学習は[setup_JP.md](https://github.com/mf-3d/thinkerAI/blob/main/docs/setup_JP.md)をご覧ください。** -->

# thinkerAIの学習方法

thinkerAIを追加学習するためのデータセット（JSON）が用意します。
そしてリポジトリの`./python/`にある、`train_model.py`を実行します。


*train_model.pyの起動コマンドのサンプル*
```
python ./python/train_model.py -f [データセットのパス] -O [モデルの出力場所]
```

# 学習したモデルの使用方法

現在、プログラムは学習したモデルが`./outputs/`に作成されることを前提に想定しているため、使用する際は`./outputs/`を上書きしてください。

**（上書きの際はバックアップを行うことを推奨します。）**