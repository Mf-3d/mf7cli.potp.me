<table>
<tbody>
  <tr>
    <td><a href="https://github.com/mf-3d/thinkerAI/blob/main/docs/train.md">English</a></td>
    <td><a href="https://github.com/mf-3d/thinkerAI/blob/main/docs/train_JP.md">日本語</a></td>
  </tr>
  </tbody>
</table>

# How does thinkerAI train?

A dataset (JSON) is prepared for additional learning of thinkerAI.
Then run `train_model.py` in `./python/`.

*Sample launch command for train_model.py*
```
python ./python/train_model.py -f [dataset path] -O [model output path]
```

# How to use the learned model?

Currently the program expects trained models to be created in `./outputs/`, so overwrite the `./outputs/` folder when using it.
**(It is recommended to back up when overwriting.)**