/* 環境設定の読み込み */
require("dotenv").config();

/* 定期実行用 */
const schedule = require('node-schedule');

/* Pythonプロセス用モジュール */
const { PythonShell } = require("python-shell");

/* API用モジュール */
const api = require("./lib/api");

/* 通知確認用のモジュール */
const notificationCheck = require("./main/notificationCheck");

/* その他 */
const conversation = require("./lib/conversation");
const twitter = require("./lib/twitter");
const { OAuthUser1 } = require("./lib/oauth_user");
const oauthUser1 = new OAuthUser1();

twitter.event.on("replied", 
/** @param {import("twitter-api-v2").TweetV2SingleResult} tweet */
async (tweet) => {
  twitter.like(tweet.data.id);
  console.log(tweet.data.conversation_id);
  await conversation.addTweet(tweet.data.conversation_id, tweet.data.id, tweet.data.text);
  const tweetDatas = await conversation.getConversation(tweet.data.conversation_id);

  console.log(JSON.stringify(tweetDatas,null,'\t'));
  let tweet_texts = [];

  tweetDatas.data.tweets.forEach((tweetData) => {
    tweet_texts[tweet_texts.length] = tweetData.text;
  });

  let replyChance = Math.floor(Math.random() * (60 - 0) + 0);
  console.log(replyChance);
  if (replyChance === 0) {
    console.log("😟");
    return;
  }

  let replyData = await api.interactWithHistory(tweet.data.text.replace(/@[0-9a-zA-Z_]{1,15}/g, ""), tweet_texts);

  if (!replyData.reply) replyData.reply = "(空白のメッセージが生成されたため、このメッセージが表示されています。)";

  const reply = await twitter.reply(replyData.reply.replace(/@[0-9a-zA-Z_]{1,15}/g, "").replace(/https?:\/\/[-_.!~*\'()a-zA-Z0-9;\/?:\@&=+\$,%#\u3000-\u30FE\u4E00-\u9FA0\uFF01-\uFFE3]+/g, "(URL)"), tweet.data.id);
  
  if (!reply) {
    console.error("😔")
    return;
  }
  const replyTweet = await twitter.getTweet(reply.data.id);
  await conversation.addTweet(replyTweet.data.conversation_id, replyTweet.data.id, replyTweet.data.text);
});

oauthUser1.event.on("replied", async (tweet) => {
  let replyData = await api.interactWithHistory(tweet.data.text.replace(/@[0-9a-zA-Z_]{1,15}/g, ""), []);
  if (!replyData.reply) replyData.reply = "(空白のメッセージが生成されたため、このメッセージが表示されています。)";

  await oauthUser1.reply(replyData.reply.replace(/@[0-9a-zA-Z_]{1,15}/g, "").replace(/https?:\/\/[-_.!~*\'()a-zA-Z0-9;\/?:\@&=+\$,%#\u3000-\u30FE\u4E00-\u9FA0\uFF01-\uFFE3]+/g, "(URL)"), tweet.data.id);
});

/* Pythonプロセスの立ち上げ */
let indexPy = new PythonShell(`${__dirname}/python/index.py`, {
  pythonPath: `${__dirname}/thinkerAI/bin/python3`,
  cwd: `${__dirname}/python`
});

indexPy.on("error", (error) => {
  console.error("PythonShell ERROR:", error);
});

indexPy.on("pythonError", (error) => {
  console.error("Python ERROR:", error);
});

indexPy.on("message", (message) => {
  console.info("Python INFO:", message);
});

indexPy.on("close", () => {
  restartPython();
});

process.on("exit", () => {
  console.log("Terminating Python process...")
  indexPy.kill();
});

/* ループ */
(function loop() {
  let Rand = Math.round(Math.random() * (2 - 0.2)) + 0.2;
  setTimeout(async function () {
    await notificationCheck.queueCheck();
    await egoSearch();

    if ((Math.round(Math.random() * (5 - 0)) + 0) === 0) await tweet();

    loop();
  }, Rand * 60000);
})();

async function tweet() {
  const texts = await api.generate("やあ。");

  if (!texts.text) return;
  
  const text = texts.text[Math.floor(Math.random() * (texts.text.length - 0) + 0)].replace(/@[0-9a-zA-Z_]{1,15}/g, "").replace(/https?:\/\/[-_.!~*\'()a-zA-Z0-9;\/?:\@&=+\$,%#\u3000-\u30FE\u4E00-\u9FA0\uFF01-\uFFE3]+/g, "(URL)").replace(/<\/s>/g, "\n").replace("やあ。", "");

  if (!text) return;
  await twitter.tweet(text);
}

async function restartPython () {
  twitter.tweet(`Pythonプロセスを再起動しています...${new Date()}`);
  console.log("INFO: Python process is restarting...");
  indexPy.kill();

  indexPy = new PythonShell(`${__dirname}/python/index.py`, {
    pythonPath: `${__dirname}/thinkerAI/bin/python3`,
    cwd: `${__dirname}/python`
  });
}

async function egoSearch () {
  // const searchedTweets = await twitter.search("to:thonkerBell", {
  //   "tweet.fields": [ "referenced_tweets" ]
  // });

  // for await (const tweet of searchedTweets) {
  //   await twitter.like(tweet.id);
  // }
}

const job = schedule.scheduleJob('0 0 * * * *', restartPython);
const job2 = schedule.scheduleJob('0 30 * * * *', restartPython);
