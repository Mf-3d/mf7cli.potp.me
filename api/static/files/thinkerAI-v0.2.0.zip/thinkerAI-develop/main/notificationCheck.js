const queueManager = require("../lib/queue")

module.exports = {
  async queueCheck() {
    const queueFile = await queueManager.getQueue();

    if (queueFile.queues.length > 0) {
      if (queueFile.queues[0].type === "reply") {
        await queueFile.deleteQueue(0);
        // 返信処理
      } else if (queueFile.queues[0].type === "conversation") {
        let queueDate = queueFile.queues[0].editedDate ? queueFile.queues[0].editedDate : queueFile.queues[0].addedDate;
        let date1 = new Date(queueDate);
        date1.setHours(date1.getHours() + 1);
        let date2 = new Date();

        if (date1 <= date2) {
          await queueManager.deleteQueue(0);
        }
      } else {
        let queueDate = queueFile.queues[0].editedDate ? queueFile.queues[0].editedDate : queueFile.queues[0].addedDate;
        let date1 = new Date(queueDate);
        date1.setHours(date1.getHours() + 1);
        let date2 = new Date();

        if (date1 <= date2) {
          await queueManager.deleteQueue(0);
        }
      }

      if (queueFile.queues.length === 1) return;

      queueFile.queues.forEach(async (queue, queueNumber) => {
        if (queueNumber === 0) return;

        let Rand2 = Math.round(Math.random() * (0.4 - 0.2)) + 0.2;

        setTimeout(async function () {
          if (queue.type === "reply") {
            await queueManager.deleteQueue(queueNumber);
            // 返信処理
          } else if (queue.type === "conversation") {
            let queueDate = queue.editedDate ? queue.editedDate : queue.addedDate;
            let date1 = new Date(queueDate);
            date1.setHours(date1.getHours() + 1);
            let date2 = new Date();
    
            if (date1 <= date2) {
              await queueManager.deleteQueue(0);
            }
          }
        }, Rand2 * 60000);
      });
    }
  }
}