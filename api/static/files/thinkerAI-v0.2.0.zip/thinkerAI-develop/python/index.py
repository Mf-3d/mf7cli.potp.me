from flask import Flask, jsonify, request
import train_model
import datetime

# モデルの読み込み
model = train_model.ConvAIModel("outputs/")

started_time = datetime.datetime.today()
# personalityを与えます
personality=[
  "私の名前はthinkerAI試作機Aだよ😟",
  "私の製造元はthinkingだよ😟",
  "私はSorakimeが大好きなんだよね😟",
  "私は絵文字が大好き",
  "私はTwitterしかしていないよ",
  "私の誕生日は10月16日だよ",
  "私はTwitterに住んでいるよ",
  "Mixcodeは男の娘だよ",
  "Mixcodeはかわいいよ",
  f"今日は{started_time.month}月{started_time.day}日だよ",
  f"今年は{started_time.year}年だよ"
]


app = Flask(__name__)

app.config['JSON_AS_ASCII'] = False

@app.route('/api/v1/interact/')
def analyse():
  print(request.args.get('text'))
  if request.args.get('text') and request.args.get('history'):
    # print('API accessed: /api/v1/emotions/analyse')
    history = []
    print(request.args.get('history').replace("'", ""))
    history = request.args.get('history').replace("'", "").split(',')
    history.pop(0)
    
    text = request.args.get('text').replace("'", "")
    reply, history = model.interact_single(text, history=history, personality=personality)

    return jsonify({
      "reply": reply,
      "history": history
    })
  else:
    return jsonify({
      "reply": None,
      "history": None
    }), 400

@app.route('/api/v1/generate')
def generate():
  if request.args.get('text'):
    text = model.generate(request.args.get('text'))

    return jsonify({
      "text": text
    })
  else: 
    return jsonify({
      "text": None
    }), 400

if __name__ == "__main__":
  app.run(host='127.0.0.1', port=20231, debug=True)