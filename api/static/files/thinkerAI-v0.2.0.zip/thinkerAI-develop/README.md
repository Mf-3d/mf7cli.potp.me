<table>
<tbody>
  <tr>
    <td><a href="https://github.com/mf-3d/thinkerAI#readme">English</a></td>
    <td><a href="https://github.com/mf-3d/thinkerAI/blob/main/README_JP.md">日本語</a></td>
  </tr>
  </tbody>
</table>

<img src="./img/logo/logo_and_text.png" width="500">

thinkerAI is an extensible chat AI platform using GPT-2.

# What is thinkerAI?

thinkerAI is a platform that can simplify the creation of GPT-2 chat AI.
The goal of this platform is to make AI more accessible.

*In the future, we plan to make it possible to operate with a GUI.*

[![License: MIT](https://img.shields.io/badge/license-MIT-blue.svg)](LICENSE)